const ownerBtn = document.getElementById('ownerBtn');
const content = document.getElementById('content');
const editPanel = document.getElementById('editPanel');
const imageInput = document.getElementById('imageInput');
const saveBtn = document.getElementById('saveBtn');

let editMode = false;

ownerBtn.addEventListener('click', () => {
    editMode = !editMode;
    content.contentEditable = editMode;
    editPanel.style.display = editMode ? 'block' : 'none';
    ownerBtn.textContent = editMode ? 'Выход из режима владельца' : 'Владелец';
});

imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(evt) {
            const img = document.createElement('img');
            img.src = evt.target.result;
            img.className = 'profile-photo';
            content.appendChild(img);
        }
        reader.readAsDataURL(file);
    }
});

saveBtn.addEventListener('click', () => {
    localStorage.setItem('dashaWiki', content.innerHTML);
    alert('Изменения сохранены!');
});

window.addEventListener('load', () => {
    const saved = localStorage.getItem('dashaWiki');
    if (saved) content.innerHTML = saved;
});
